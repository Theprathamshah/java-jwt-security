import React, { useState } from 'react'
import axios from 'axios';
import { useAuth } from '../AuthProvider';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const Login = () => {
    
    const [input, setInput] = useState({
        username: "",
        password: "",
    });
    const auth = useAuth();
    const URL = 'http://localhost:8080/auth/login';

    const handleInput = (e) => {
        const { name, value } = e.target;
        setInput((prev) => ({
            ...prev, [name]: value,
        }))

    }

    const handleSubmint = (e) => {
        e.preventDefault();
        console.log(input);

        
        if (input.email !== "" && input.password !== "") {
            auth.loginAction(input);
            return;
        }
        else {
            toast('Please enter email and password', {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
            });
        
        }
    }

    return (
        <form onSubmit={handleSubmint}>
            <div className="form_control">
                <label htmlFor="user-email">Email:</label>
                <input
                    type="email"
                    id="user-email"
                    name="email"
                    placeholder="example@yahoo.com"
                    aria-describedby="user-email"
                    aria-invalid="false"
                    onChange={handleInput}
                />

            </div>
            <div className="form_control">
                <label htmlFor="password">Password:</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    aria-describedby="user-password"
                    aria-invalid="false"
                    onChange={handleInput}
                />

            </div>
            <button className="btn-submit">Submit</button>
        </form>
    )
}

export default Login;
