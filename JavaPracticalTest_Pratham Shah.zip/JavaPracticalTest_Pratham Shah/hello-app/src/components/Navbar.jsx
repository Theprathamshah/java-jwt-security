import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';


import { useAuth } from '../AuthProvider';
import { useNavigate } from 'react-router'

export default function ButtonAppBar() {
    const navigate = useNavigate();
    const auth = useAuth();
    const userExist = auth.user?.email;
    
    return (
        <Box sx={{ flexGrow: 1 }}>
            <AppBar position="static">
                <Toolbar>
                    
                    <Typography variant="h6" component="div"  sx={{ flexGrow: 1,textAlign:"center" }}>
                        Mother's Care
                    </Typography>

                    {
                        auth.user?.email ? (<Button variant="contained" onClick={() => auth.logOut()} className="">
                                            Logout
                                    </Button>):
                                    (<Button onClick={() => navigate("/login")} color="inherit">Login</Button>)
                    }
                    
                </Toolbar>
            </AppBar>
        </Box>
    );
}