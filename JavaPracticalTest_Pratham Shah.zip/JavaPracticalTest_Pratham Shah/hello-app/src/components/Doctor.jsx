import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { DoctorCard } from './DoctorCard';
import { useAuth } from '../AuthProvider';


const Doctor = () => {
    const [doctors, setDoctors] = useState([]);
    const url = 'http://localhost:8080/api/v1/doctors';
    const auth = useAuth();
    
    const getDoctors = ()=>{
        console.log(auth);
        
        axios.get(url,{
            auth: {
                email: auth.user?.email,
                password: auth.user?.password
            }
        }).then((response)=>{
            console.log(response.data);
            
            setDoctors(response.data);
        })
    }
    useEffect(()=>{
        getDoctors()
    },[]);
  return (
    <div>
      
        {
            doctors.map(doctor=>(
                <DoctorCard doctor={doctor} key={doctor.id}/>
            ))
        }
    </div>
  )
}

export default Doctor
