import React from 'react'
import { useAuth } from '../AuthProvider';
import { Container } from '@mui/system';
import { useNavigate } from 'react-router';
import  Button  from '@mui/material/Button';
const DashBoard = () => {
    const navigate = useNavigate();
    
    const auth = useAuth();
    return (
        <div className="container">
            <div>
                <h1>Welcome! {auth.user?.email}</h1>
                
            </div>
            

            <Button variant="outlined" color="primary" sx={{marginRight:10}} onClick={()=>navigate("/doctors")}>Doctors</Button>
            <Button variant="outlined" color="primary" sx={{marginRight:10}} onClick={()=>navigate("/patients")}>Patients</Button>
            <Button variant="outlined" color="primary" onClick={()=>navigate("/")}>Users</Button>
            
        </div>
    );
}

export default DashBoard
