import React from 'react'
import { useNavigate } from 'react-router'
import {jwtDecode} from "jwt-decode";
import Typography from "@mui/material/Typography"
import { width, Container } from '@mui/system';
const Home = () => {
    const navigate = useNavigate();
    const token = localStorage.getItem("site" || "");
    console.log(token);
    
    return (
        <div style={{height:"92.6vh",
            background: `linear-gradient( 
to right
 #95ade6, #14ca51 )` }}>
            <Container sx={{height:"50%" ,width:"50%",padding:10}}>
                <Typography className="welcome-text" variant="h6" component="div" sx={{flexGrow:1}}>Welcome to Mother's Care Hospital, where we prioritize the health and well-being of both mothers and their precious little ones. As a premier healthcare facility dedicated to maternal and child health, we strive to provide exceptional care and support to expecting mothers, newborns, and families alike. At Mother's Care, we understand the significance of this transformative journey and aim to create a nurturing environment where every pregnancy is cherished, every birth celebrated, and every family feels empowered. With a team of compassionate healthcare professionals, state-of-the-art facilities, and a commitment to excellence, we offer a comprehensive range of services spanning prenatal care, childbirth, postnatal support, pediatric care, and beyond. Whether it's guidance through pregnancy, expert medical attention during delivery, or specialized care for infants and children, Mother's Care Hospital is here to ensure that every mother receives the care she deserves and every child begins life with the best possible start. Trust in us as your partner in health, because at Mother's Care, your family is our priority.</Typography>
            </Container>
        </div>


    )
}

export default Home
/*
package com.prathamcodes.hospitalmanagement.services;

import com.auth0.jwt.algorithms.Algorithm;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import com.auth0.jwt.JWT;


@Component
public class JwtService {
    public static final String SECRET = "5367566B59703373367639792F423F4528482B4D6251655468576D5A71347437";
    public String generateToken(String email,Long userId,String claims){

        return createToken(userId,email,claims);
    }
    private String createToken(Long userId,String role,String email){
        return JWT.create().withSubject(String.valueOf(userId)).withIssuedAt(Instant.now())
                .withExpiresAt(Instant.now().plus(Duration.of(1, ChronoUnit.DAYS)))
                .withClaim("email",email)
                .withClaim("roles",role)
                .sign(Algorithm.HMAC256(SECRET));
    }
    private Key getSignKey(){
        byte[] keyBytes = Decoders.BASE64.decode(SECRET);
        return Keys.hmacShaKeyFor(keyBytes);
    }
    public String extractEmail(String token){
        return extractClaim(token, Claims::getSubject);
    }
    public Date extractExpiration(String token){
        return extractClaim(token,Claims::getExpiration);
    }
    public <T> T extractClaim(String token, Function<Claims,T> claimsResolver){
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }
    private Claims extractAllClaims(String token){
        return Jwts.parserBuilder()
                .setSigningKey(getSignKey())
                .build()
                .parseClaimsJwt(token)
                .getBody();
    }
    private Boolean isTokenExpired(String token){
        return extractExpiration(token).before(new Date());
    }
    public Boolean validateToken(String token, UserDetails userDetails){
        final String email = extractEmail(token);
        return (email.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }
}


*/