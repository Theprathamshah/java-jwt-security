import React from 'react'

const Signup = () => {
    return (
        <div>
            <h1>This is a Signup page</h1>
        </div>
    )
}

export default Signup
