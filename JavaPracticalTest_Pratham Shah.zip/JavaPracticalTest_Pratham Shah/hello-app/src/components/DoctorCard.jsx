import React from 'react'
import { Button } from '@mui/material'
import { TimePicker } from '@mui/x-date-pickers'

export const DoctorCard = ({ doctor }) => {

    return (

        <div style={{display:"flex",alignItems:"center",gap:20}}>
            <h2>{doctor.name}</h2>
            <h4>{doctor.address}</h4>
            <h4>{doctor.email}</h4>
            <h4>{doctor.workingHoursStart}</h4>
            <h4>{doctor.workingHoursEnd}</h4>
            <TimePicker/>
            <Button onClick={()=>console.log(doctor.id)}>Book Appointment</Button>
        </div>
    )
}
