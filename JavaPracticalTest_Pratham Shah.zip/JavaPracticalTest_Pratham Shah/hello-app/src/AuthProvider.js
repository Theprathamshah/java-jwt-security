/*
import React from 'react'
import { useContext, createContext ,useState} from "react";
import {useNavigate} from 'react-router-dom';
const AuthContext=createContext();
const AuthProvider = ({children}) => {
    const [user, setUser] = useState(null);
    const [token, setToken] = useState(localStorage.getItem("site")||"");
    const navigate = useNavigate();
    const URL = 'http://localhost:8080/auth/login';

    const loginAction = async (data)=>{
        try {
            const response = await fetch(URL,{
                method:"POST",
                headers:{
                    "Content-Type":"application/json",
                },
                body:JSON.stringify(data),
            });
            const res = await response.json();
            console.log(res.data);
            
            if(res.data){
                setUser(res.data.user);
                setToken(res.token);
                localStorage.setItem("site",res.token);
                navigate("/dashboard");
                return;
            }
            throw new Error(res.message);
            
        }catch(err){
            console.error(err);
        }
    }

    const logout=()=>{
        setUser(null);
        setToken("");
        localStorage.removeItem("site");
        navigate("/login");
    }
    return (
        <AuthContext.Provider>
            {children}
        </AuthContext.Provider>
    )
}

export default AuthProvider

export const useAuth = ()=>{
    return useContext(AuthContext);
}

*/

import { useContext, createContext, useState } from "react";
import 'react-toastify/dist/ReactToastify.css';

import { useNavigate } from 'react-router'
import { ToastContainer, toast } from 'react-toastify';
const AuthContext = createContext();

const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [token, setToken] = useState(localStorage.getItem("site") || "");
    const navigate = useNavigate();
    const URL = 'http://localhost:8080/api/v1/auth/login';

    const loginAction = async (data) => {
        try {
            const response = await fetch(URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            });
            console.log(response);

            
            if (response.status===401) {
                toast('Please enter correct email and password', {
                    position: "top-right",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light",
                });
                
            }
            const res = await response.json();
            if (res) {
                setUser(res.user);
                setToken(res.accessToken);
                localStorage.setItem("site", res.accessToken);
                if(res.accessToken=="ROLE_USER"){
                    navigate("/profile")
                }else if(res.AuthContext==="ROLE_DOCTOR"){

                }else{

                    navigate("/dashboard");
                }
                return;
            }
            throw new Error(res.message);
        } catch (err) {
            console.error(err);
        }
    };

    const logOut = () => {
        setUser(null);
        setToken("");
        localStorage.removeItem("site");
        navigate("/login");
    };

    return (
        <AuthContext.Provider value={{ token, user, loginAction, logOut }}>
            {children}
        </AuthContext.Provider>
    );

};

export default AuthProvider;

export const useAuth = () => {
    return useContext(AuthContext);
};