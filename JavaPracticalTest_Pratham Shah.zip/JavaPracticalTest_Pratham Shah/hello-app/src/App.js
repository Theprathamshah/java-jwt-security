import logo from './logo.svg';
import './App.css';
import Home from "./components/Home"
import Login from "./components/Login"
import axios from 'axios';
import PrivateRoute from "./PrivateRoute";
import React, { useState } from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AuthProvider from "./AuthProvider";
import DashBoard from './components/DashBoard';
import ButtonAppBar from './components/Navbar';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Doctor from './components/Doctor';
function App() {

  return (
    <BrowserRouter>
      <ToastContainer />
      <AuthProvider>
        <ButtonAppBar />
        <Routes>
          <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
          <Route element={<PrivateRoute />} >
            <Route path="/dashboard" element={<DashBoard />} />
            <Route path="/doctors" element={<Doctor/>}/>
          </Route>
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  )


}

export default App;
