package com.prathamcodes.hospitalmanagement.entity;

public class Appointment {
}
